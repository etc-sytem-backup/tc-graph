#!/bin/bash

# a2_sc_list.csv からキーと車種コードのマッピングを作成
awk -F, '{
    key = substr($15, 20, 15);
    gsub("f", "", key);  # キーから「f」を削除
    gsub(/^[ \t]+|[ \t]+$/, "", key);  # キーの前後の空白を削除
    syaryo_code = substr($15, 15, 3);
    gsub(/^[ \t]+|[ \t]+$/, "", syaryo_code);  # 車種コードの前後の空白を削除
    if (key != "" && syaryo_code != "") print key "," syaryo_code;  # カンマ区切りで出力
}' ./a2_sc_list.csv > key_syaryocode_map.txt

# WCN_rireki_all.csv を処理して結果を出力
awk -F, -v OFS=, 'NR==FNR {
    map[$1] = $2;
    next
}
{
    key = $7 $8 $9 $10;  # WCN_rireki_all.csv からキーを生成
    if (map[key] != "") {
        print $1, $2, $3, $4, $5, $6, map[key], $7, $8, $9, $10;
    } else {
        print $1, $2, $3, $4, $5, $6, "*", $7, $8, $9, $10;  # マッチしない場合
    }
}' ./key_syaryocode_map.txt ./WCN_rireki_all.csv > ./WCN_rireki_all_add_syaryocode.csv



