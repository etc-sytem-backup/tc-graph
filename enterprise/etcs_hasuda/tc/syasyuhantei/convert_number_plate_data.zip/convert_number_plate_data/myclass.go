// アプリ用構造体定義
package main

type ConvNP_st struct {
    
}

/* 用途コードを平仮名に変換*/
func (c *ConvNP_st) Change_youto_code(code string) string {

    var result = ""

    switch code {

    // 自家用
    case "bb": // さ
        result = "さ"
    case "bd": // す
        result = "す"
    case "be": // せ
        result = "せ"
    case "bf": // そ
        result = "そ"
    case "c0": // た
        result = "た"
    case "c1": // ち
        result = "ち"
    case "c2": // つ
        result = "つ"
    case "c3": // て
        result = "て"
    case "c4": // と
        result = "と"
    case "c5": // な
        result = "な"
    case "c6": // に
        result = "に"
    case "c7": // ぬ
        result = "ぬ"
    case "c8": // ね
        result = "ね"
    case "c9": // の
        result = "の"
    case "ca": // は
        result = "は"
    case "cb": // ひ
        result = "ひ"
    case "cc": // ふ
        result = "ふ"
    case "ce": // ほ
        result = "ほ"
    case "cf": // ま
        result = "ま"
    case "d0": // み
        result = "み"
    case "d1": // む
        result = "む"
    case "d2": // め
        result = "め"
    case "d3": // も
        result = "も"
    case "d4": // や
        result = "や"
    case "d5": // ゆ
        result = "ゆ"
    case "d7": // ら
        result = "ら"
    case "d8": // り
        result = "り"
    case "d9": // る
        result = "る"
    case "db": // ろ
        result = "ろ"

    // 貸渡（レンタカー）
    case "da": // れ
        result = "れ"
    case "dc": // わ
        result = "わ"

    // 事業用
    case "b1": // あ
        result = "あ"
    case "b2": // い
        result = "い"
    case "b3": // う
        result = "う"
    case "b4": // え
        result = "え"
    case "b6": // か
        result = "か"
    case "b7": // き
        result = "き"
    case "b8": // く
        result = "く"
    case "b9": // け
        result = "け"
    case "ba": // こ
        result = "こ"
    case "a6": // を
        result = "を"

    // 駐留軍人軍属私有車両用等
    case "45": // E
        result = "Ｅ"
    case "48": // H
        result = "Ｈ"
    case "4b": // K
        result = "Ｋ"
    case "4d": // M
        result = "Ｍ"
    case "54": // T
        result = "Ｔ"
    case "59": // Y
        result = "Ｙ"
    case "d6": // よ
        result = "よ"
    default:
        result = code
        //result = "*"
    }

    return result
}

/*陸運局支局コードを地名に変換*/
func (c *ConvNP_st) Change_sikyoku_code(code string) string {

    var result = ""

    switch code {
    case "535053": // 札幌 SPS
        result = "札幌"
    case "535020": // 札   SP 
        result = "札"
    case "484448": // 函館 HDH
        result = "函館"
    case "484420": // 函   HD 
        result = "函"
    case "414b41": // 旭川 AKA
        result = "旭川"
    case "414b20": // 旭   AK 
        result = "旭"
    case "4d524d": // 室蘭 MRM
        result = "室蘭"
    case "4d5220": // 室   MR 
        result = "室"
    case "4b524b": // 釧路 KRK
        result = "釧路"
    case "4b5220": // 釧   KR 
        result = "釧"
    case "4f484f": // 帯広 OHO
        result = "帯広"
    case "4f4820": // 帯   OH 
        result = "帯"
    case "4b494b": // 北見 KIK
        result = "北見"
    case "4b4920": // 北   KI 
        result = "北"
    case "414d41": // 青森 AMA
        result = "青森"
    case "414d48": // 八戸 AMH
        result = "八戸"
    case "414d20": // 青   AM 
        result = "青"
    case "495449": // 岩手 ITI
        result = "岩手"
    case "495420": // 岩   IT 
        result = "岩"
    case "4d4753": // 仙台 MGS
        result = "仙台"
    case "4d474d": // 宮城 MGM
        result = "宮城"
    case "4d4720": // 宮   MG 
        result = "宮"
    case "415441": // 秋田 ATA
        result = "秋田"
    case "415420": // 秋   AT 
        result = "秋"
    case "594120": // 山形 YA 
        result = "山形"
    case "594153": // 庄内 YAS
        result = "庄内"
    case "465320": // 福島 FS 
        result = "福島"
    case "465341": // 会津 FSA
        result = "会津"
    case "465349": // いわきFSI
        result = "いわき"
    case "49474d": // 水戸 IGM
        result = "水戸"
    case "494754": // 土浦 IGT
        result = "土浦"
    case "49474b": // つくばIGK
        result = "つくば"
    case "494749": // 茨城 IGI
        result = "茨城"
    case "494720": // 茨   IG 
        result = "茨"
    case "544755": // 宇都宮TGU
        result = "宇都宮"
    case "54474e": // 那須 TGN
        result = "那須"
    case "544743": // とちぎTGC
        result = "とちぎ"
    case "544754": // 栃木 TGT
        result = "栃木"
    case "544720": // 栃   TG 
        result = "栃"
    case "474d47": // 群馬 GMG
        result = "群馬"
    case "474d54": // 高崎 GMT
        result = "高崎"
    case "474d20": // 群   GM 
        result = "群"
    case "53544f": // 大宮 STO
        result = "大宮"
    case "535447": // 川越 STG
        result = "川越"
    case "535454": // 所沢 STT
        result = "所沢"
    case "53544b": // 熊谷 STK
        result = "熊谷"
    case "535442": // 春日部STB
        result = "春日部"
    case "535453": // 埼玉 STS
        result = "埼玉"
    case "535420": // 埼   ST 
        result = "埼"
    case "434243": // 千葉 CBC
        result = "千葉"
    case "434254": // 成田 CBT
        result = "成田"
    case "43424e": // 習志野CBN
        result = "習志野"
    case "434253": // 袖ヶ浦CBS
        result = "袖ヶ浦"
    case "434244": // 野田 CBD
        result = "野田"
    case "43424b": // 柏   CBK
        result = "柏"
    case "434220": // 千   CB 
        result = "千"
    case "544b53": // 品川 TKS
        result = "品川"
    case "544f53": // 品   TOS
        result = "品"
    case "544b4e": // 練馬 TKN
        result = "練馬"
    case "544f4e": // 練   TON
        result = "練"
    case "544b41": // 足立 TKA
        result = "足立"
    case "544f41": // 足   TOA
        result = "足"
    case "544b48": // 八王子TKH
        result = "八王子"
    case "544b54": // 多摩 TKT
        result = "多摩"
    case "544f54": // 多   TOT
        result = "多"
    case "4b4e59": // 横浜 KNY
        result = "横浜"
    case "4b4e4b": // 川崎 KNK
        result = "川崎"
    case "4b4e4e": // 湘南 KNN
        result = "湘南"
    case "4b4e53": // 相模 KNS
        result = "相模"
    case "4b4e20": // 神   KN 
        result = "神"
    case "594e20": // 山梨 YN 
        result = "山梨"
    case "464a53": // 富士山FJS
        result = "富士山"
    case "4e474e": // 新潟 NGN
        result = "新潟"
    case "4e474f": // 長岡 NGO
        result = "長岡"
    case "4e4720": // 新   NG 
        result = "新"
    case "545954": // 富山 TYT
        result = "富山"
    case "545920": // 富   TY 
        result = "富"
    case "494b4b": // 金沢 IKK
        result = "金沢"
    case "494b49": // 石川 IKI
        result = "石川"
    case "494b20": // 石   IK 
        result = "石"
    case "4e4e4e": // 長野 NNN
        result = "長野"
    case "4e4e4d": // 松本 NNM
        result = "松本"
    case "4e4e53": // 諏訪 NNS
        result = "諏訪"
    case "4e4e20": // 長   NN 
        result = "長"
    case "464920": // 福井 FI 
        result = "福井"
    case "474647": // 岐阜 GFG
        result = "岐阜"
    case "474648": // 飛騨 GFH
        result = "飛騨"
    case "474620": // 岐   GF 
        result = "岐"
    case "535a53": // 静岡 SZS
        result = "静岡"
    case "535a48": // 浜松 SZH
        result = "浜松"
    case "535a4e": // 沼津 SZN
        result = "沼津"
    case "535a49": // 伊豆 SZI
        result = "伊豆"
    case "535a20": // 静   SZ 
        result = "静"
    case "41434e": // 名古屋ACN
        result = "名古屋"
    case "414354": // 豊橋 ACT
        result = "豊橋"
    case "41435a": // 岡崎 ACZ
        result = "岡崎"
    case "41434d": // 三河 ACM
        result = "三河"
    case "414359": // 豊田 ACY
        result = "豊田"
    case "414349": // 一宮 ACI
        result = "一宮"
    case "41434f": // 尾張小ACO牧
        result = "尾張小"
    case "414320": // 愛   AC 
        result = "愛"
    case "4d454d": // 三重 MEM
        result = "三重"
    case "4d4553": // 鈴鹿 MES
        result = "鈴鹿"
    case "4d4520": // 三   ME 
        result = "三"
    case "534953": // 滋賀 SIS
        result = "滋賀"
    case "534920": // 滋   SI 
        result = "滋"
    case "4b544b": // 京都 KTK
        result = "京都"
    case "4b5420": // 京   KT 
        result = "京"
    case "4f534f": // 大阪 OSO
        result = "大阪"
    case "4f534e": // なにわOSN
        result = "なにわ"
    case "4f5353": // 堺   OSS
        result = "堺"
    case "4f535a": // 和泉 OSZ
        result = "和泉"
    case "4f5320": // 大   OS 
        result = "大"
    case "4f5349": // 泉   OSI
        result = "泉"
    case "48474b": // 神戸 HGK
        result = "神戸"
    case "484748": // 姫路 HGH
        result = "姫路"
    case "484720": // 兵   HG 
        result = "兵"
    case "4e524e": // 奈良 NRN
        result = "奈良"
    case "4e5220": // 奈   NR 
        result = "奈"
    case "574b57": // 和歌山WKW
        result = "和歌山"
    case "574b20": // 和   WK 
        result = "和"
    case "545454": // 鳥取 TTT
        result = "鳥取"
    case "545420": // 鳥   TT 
        result = "鳥"
    case "534e20": // 島根 SN 
        result = "島根"
    case "534d20": // 島   SM 
        result = "島"
    case "4f594f": // 岡山 OYO
        result = "岡山"
    case "4f594b": // 倉敷 OYK
        result = "倉敷"
    case "4f5920": // 岡   OY 
        result = "岡"
    case "485348": // 広島 HSH
        result = "広島"
    case "485346": // 福山 HSF
        result = "福山"
    case "485320": // 広   HS 
        result = "広"
    case "595553": // 下関 YUS
        result = "下関"
    case "595559": // 山口 YUY
        result = "山口"
    case "595520": // 山   YU 
        result = "山"
    case "545354": // 徳島 TST
        result = "徳島"
    case "545320": // 徳   TS 
        result = "徳"
    case "4b414b": // 香川 KAK
        result = "香川"
    case "4b4120": // 香   KA 
        result = "香"
    case "454820": // 愛媛 EH 
        result = "愛媛"
    case "4b434b": // 高知 KCK
        result = "高知"
    case "4b4320": // 高   KC 
        result = "高"
    case "464f46": // 福岡 FOF
        result = "福岡"
    case "464f4b": // 北九州FOK
        result = "北九州"
    case "464f52": // 久留米FOR
        result = "久留米"
    case "464f43": // 筑豊 FOC
        result = "筑豊"
    case "464f20": // 福   FO 
        result = "福"
    case "534153": // 佐賀 SAS
        result = "佐賀"
    case "534120": // 佐   SA 
        result = "佐"
    case "4e5320": // 長崎 NS 
        result = "長崎"
    case "4e5353": // 佐世保NSS
        result = "佐世保"
    case "4b554b": // 熊本 KUK
        result = "熊本"
    case "4b5520": // 熊   KU 
        result = "熊"
    case "4f5420": // 大分 OT 
        result = "大分"
    case "4d5a20": // 宮崎 MZ 
        result = "宮崎"
    case "4b4f4b": // 鹿児島KOK
        result = "鹿児島"
    case "4b4f20": // 鹿   KO 
        result = "鹿"
    case "4f4e4f": // 沖縄 ONO
        result = "沖縄"
    case "4f4e20": // 沖   ON 
        result = "沖"
    default:
        result = code
        //result = "*"
    }

    return result
}

// make_etc_syasyuhantei関数は、原本コードによるETC車種判定(大型 or 小型)を返します。
func (c *ConvNP_st) Make_etc_syasyuhantei(param string) string {
    var result string

    // paramの左端文字を切り出します
    firstChar := string(param[0])
    
    switch firstChar {
    case "1":
        result = "小型"
    case "2":
        result = "大型"
    case "3":        
        result = "大型"
    case "4":
        result = "大型"
    case "5":
        result = "小型"
    case "6":
        result = "小型"
    default:
        //result = "*"
        result = firstChar
    }
    
    return result
}


// make_etc_hanteicodeは、原本コードから導き出された判定コードを返します。
func (c *ConvNP_st) Make_etc_hanteicode(param string) string {
    var result string

    firstChar := string(param[0])
    if firstChar == "*" {
        result = "*"
    } else {
        // paramの左端文字を切り出します
        result = firstChar
    }
    
    return result
}

// make_etc_jikayou関数は、自家用原本コードか否かを返します。否の場合は「*」を返します。
func (c *ConvNP_st) Make_etc_jikayou(param string) string {
    var result string

    result = param

    // 一致する場合はそのまま。一致しない場合は*を返す。
    switch param {
    case "130":
    case "132":
    case "140":
    case "142":
    case "144":
    case "146":
    case "150":
    case "152":
    case "160":
    case "162":
    case "210":
    case "212":
    case "220":
    case "222":
    case "310":
    case "312":
    case "320":
    case "322":
    case "390":
    case "410":
    case "412":
    case "416":
    case "420":
    case "422":
    case "540":
    case "542":
    case "550":
    case "552":
    case "580":
    case "582":
    case "590":
    case "592":
    case "690":
    case "790":
    case "890":
    default:
        //result = "*"
        result = param
    }

    return result
}

func (c *ConvNP_st) Make_etc_jigyou(param string) string {
    var result string

    result = param

    // 一致する場合はそのまま。一致しない場合は*を返す。
    switch param {
    case "131":
    case "133":
    case "141":
    case "143":
    case "145":
    case "147":
    case "151":
    case "153":
    case "161":
    case "163":
    case "211":
    case "213":
    case "221":
    case "223":
    case "311":
    case "313":
    case "321":
    case "323":
    case "391":
    case "411":
    case "413":
    case "417":
    case "421":
    case "423":
    case "541":
    case "543":
    case "551":
    case "553":
    case "581":
    case "583":
    case "591":
    case "593":
    case "691":
    case "790":
    case "890":
    default:
        //result = "*"
        result = param
    }
    
    return result
}
