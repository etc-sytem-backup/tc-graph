#!/bin/bash
### 本スクリプトはconvert_number_plate_data内から呼ばれるのではなく、任意のディレクトリに配置して、
### ターミナル上で起動する。

### ファイル配置図
# 予め、ディレクトリ群「sbox02.YYYYMMDD」と「sbox02.YYYYMMDD」を作成しておくこと。
# ※「sbox02.YYYYMMDD」と「sbox02.YYYYMMDD」は、/Users/k/sk_prj/enterprise/etcs/etcs_hasuda/data_analaysis_genshi/dust以下にバックアップされている
# ├── sbox02.20231202
# ｜      └─ 20231202000125911_SBOX_to_AP_Sc_A2_receive.csv <-- 原始データ（各ディレクトリ配下に配置されている）
# ├── sbox02.20231203
# ├── sbox02.20231204
# ・
# ・
# ├── sbox02.20231218
# ├── sbox02.20231219
# ├── sbox02.20231220
# ├── sbox02.20231221
# ├── #make_a2a3_genshi.sh <-- 原始データを一本化するスクリプト（本スクリプト）


# 開始日と終了日を設定
start_day=20231201
end_day=20231220
out_file=./a2a3_sc_list.csv

# a2,a3の原始データまとめファイルを初期化
> ${out_file}

# ヘッダーの追加フラグを設定
header_added=false

# 指定された日付範囲でループ処理
for ((i=start_day; i<=end_day; i++)); do
    for file in sbox02.$i/*SBOX_to_AP_Sc_A2_receive.csv; do
        if [ "$header_added" = false ]; then
            # 最初のファイルのヘッダーを追加
            head -n 1 "$file" >> ${out_file}
            header_added=true
        fi
        # ヘッダーを除いたデータを確認し、45文字以上の場合のみ追記
        tail -n +2 "$file" | awk 'length($0) >= 45' >> ${out_file}
    done
done

for ((i=start_day; i<=end_day; i++)); do
    for file in sbox03.$i/*SBOX_to_AP_Sc_A3_receive.csv; do
        if [ "$header_added" = false ]; then
            # 最初のファイルのヘッダーを追加
            head -n 1 "$file" >> ${out_file}
            header_added=true
        fi
        # ヘッダーを除いたデータを確認し、45文字以上の場合のみ追記
        tail -n +2 "$file" | awk 'length($0) >= 45' >> ${out_file}
    done
done

# 1列目を数値と見なし、降順にソート（重複削除）
# 一時ファイルを使用してソート結果を原始データまとめファイルに上書き
sort -t, -k1,1nr ${out_file} | uniq > temp.csv && mv temp.csv ${out_file}


