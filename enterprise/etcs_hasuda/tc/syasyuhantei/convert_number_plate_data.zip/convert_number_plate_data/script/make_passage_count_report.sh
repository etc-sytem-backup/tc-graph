#!/bin/bash
## 通過履歴の時間毎集計
## XX時00分00秒〜XX時59分59秒までのデータで集計を行う。
## 解析対象となるcsvファイルは、日毎に分割されたアンテナ通過履歴ファイル（例：WCN_rireki_20231215.csv）
## ★引数★
## csvファイルが配置されているディレクトリパス

target_path=$1
start_day=20231201
end_day=20231220

# 蓮田SAデータファイルの数だけループ（上記日付範囲のcsvファイル決め打ち）
for ((i=start_day; i<=end_day; i++)); do

    # 引数からファイル名を取得
    filename="$target_path/WCN_rireki_$i.csv"
    tempfile="temp_converted.csv"

    # ファイルが存在しない場合は次のループへ
    if [[ ! -f "$filename" ]]; then
        echo "File not found: $filename"
        continue
    fi

    # Shift-JISからUTF-8に変換
    iconv -f SHIFT_JIS -t UTF-8 "$filename" > "$tempfile"

    # ファイル名と日付を抽出
    date=$(head -2 "$tempfile" | tail -1 | cut -d',' -f1 | cut -c 1-8)
    echo "date is : ${date}"

    # 日付が8桁の数字でない場合、次のループに進む
    if ! [[ $date =~ ^[0-9]{8}$ ]]; then
        echo "Invalid date format or '日時' found in $filename"
        continue
    fi
    
    # アンテナ位置ごとにループ
    for antenna in A1 A2 A3; do
        # 出力ファイル名の設定
        output="../30_analyse/15_Passage_count_day/${date}_${antenna}.csv"
        echo "時刻,通過車両台数,大型車台数,小型車台数" > "$output"

        # 時間ごとにデータを集計
        for hour in {00..23}; do

            # 10未満の時間に先頭の0を追加
            formatted_hour=$(printf "%02d" $hour)

            # 指定したアンテナ位置と時間でデータをフィルタリング
            hour_data=$(awk -F',' -v antenna="$antenna" -v hour="$formatted_hour" \
                            '$2 == antenna && substr($1,9,2) == hour {print substr($1,1,10), $9}' "$tempfile")
            
            if [[ -z "$hour_data" ]]; then
                # データが存在しない場合は0を出力
                total=0
                large=0
                small=0
            else
                # データが存在する場合は集計
                total=$(echo "$hour_data" | wc -l)
                large=$(echo "$hour_data" | grep '大型' | wc -l)
                small=$(echo "$hour_data" | grep '小型' | wc -l)
            fi
            
            # 結果をファイルに出力
            printf "%s,%d,%d,%d\n" "$hour" "$total" "$large" "$small" >> "$output"

        done
    done
done

# 一時ファイルの削除
rm "$tempfile"
