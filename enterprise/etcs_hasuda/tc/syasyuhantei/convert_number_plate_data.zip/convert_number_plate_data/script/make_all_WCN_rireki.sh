#!/bin/bash
### 本スクリプトはconvert_number_plate_data内から呼ばれるのではなく、convert_number_plate_dataと同じディレクトリに配置して、
### ターミナル上で起動する。

### ファイル配置図
# 予め、ディレクトリ群「tc_csv_table.YYYYMMDD」を作成しておくこと。
# ├── tc_csv_table.20231202
# ｜      └─ WCN_rireki.csv       <-- 全アンテナ通過履歴。（各ディレクトリ配下に配置されている）
# ├── tc_csv_table.20231203
# ├── tc_csv_table.20231204
# ・
# ・
# ├── tc_csv_table.20231218
# ├── tc_csv_table.20231219
# ├── tc_csv_table.20231220
# ├── tc_csv_table.20231221
# ├── config.ini                  <-- convert_number_plate_data用のコンフィグファイル（現在設定無し）
# ├── convert_number_plate_data   <-- ナンバープレート情報変換プログラム（提出用）
# ├── make_all_WCN_rireki.sh <-- 提出用のデータを日毎に分割するスクリプト（本スクリプト）

### 入力ファイル
# ├── WCN_rireki_all.csv              <-- convert_number_plate_dataの引数として指定（本スクリプトで作成）

### 出力ファイル
# ├── WCN_rireki_all_number_plate.csv <-- cnvert_number_plate_dataが作成する、片山さん連携用に変換された情報を含むCSV。

# 共通パラメータ及び関数読込
source ./param.sh 

#***************************************************
# WCN_rireki_all.csv（全アンテナ通過履歴）を作成する
#***************************************************

# 出力ファイルが存在する場合は、日付付きでバックアップしてから削除
if [[ -f "$output_file" ]]; then
    cp "$output_file" "$backup_file"
    rm "$output_file"
fi

echo "=== WCN_rireki_all.csvを作成します。"

# tc_csv_table.20231202からtc_csv_table.20231224までのディレクトリに対してループ
# ※ディレクトリは、本スクリプトが配置されているディレクトリ配下に配置されていなければならない
rm -rf ${output_day_org}/*.csv
cat_WCN_rireki_csv 20231129 20231130
#cat_WCN_rireki_csv 20231201 20231220

# 1列目を数値と見なして降順にソート
# [[ -f "$output_file" ]] && sort -t, -k1,1nr -o "$output_file" "$output_file"
# mv ${output_file.tmp} ${output_file}

rm -rf ./*.debug  # debug用ファイルを削除

# 指定された$output_fileが存在するか確認
if [[ -f "$output_file" ]]; then
    # 1列目を数値と見なして降順にソートし、結果を$output_file.tmpに出力
    sort -t, -k1,1nr -o "$output_file.tmp" "$output_file"
#    cp -rp ./$output_file.tmp ./$output_file.after_sort.debug

    # 一連番号に含まれる文字「f」を削除する。
    # ソートされたデータを含む一時ファイルから重複データを削除し、元のファイル名にリネームする
    # sed 's/f//g' "$output_file.tmp" > "output_file.tmp.without_f"
    # uniq "output_file.tmp.without_f" > "$output_file"
    # rm "output_file.tmp.without_f"

    # 一連番号に含まれる「f」を削除せず、重複データを削除する。
    uniq "$output_file.tmp" > "$output_file"
    
    # 一時ファイルを削除
    rm "$output_file.tmp"
    #    cp -rp ./$output_file ./$output_file.rename.debug

    echo "=== WCN_rireki_all.csvを作成完了。"
else
    echo "Error: File '$output_file' does not exist."
fi


#********************************************************************************************************************
# WCN_rireki_all.csvに車両コード情報を追加
#********************************************************************************************************************
# ★重要★
# 予め、原始データまとめファイル「a2a3_sc_list.csv」を作成し、このスクリプトと同じディレクトリに配置して置くこと！
#   → 作成方法 : make_a2a3_genshi.sh

echo "WCN_rireki_all.csvに車両コード列を追加します。"
echo "=== 車両コードマッピングファイル作成開始"
# a2_sc_list.csv からキーと車両コードのマッピングを作成
awk -F, '{
    key = substr($15, 20, 15);
    gsub("f", "", key);  # キーから「f」を削除
    gsub(/^[ \t]+|[ \t]+$/, "", key);  # キーの前後の空白を削除
    syaryo_code = substr($15, 15, 3);
    gsub(/^[ \t]+|[ \t]+$/, "", syaryo_code);  # 車種コードの前後の空白を削除
    if (key != "" && syaryo_code != "") print key "," syaryo_code;  # カンマ区切りで出力
}' ./a2a3_sc_list.csv > key_syaryocode_map.txt
echo "=== 車両コードマッピングファイル作成完了"

echo "=== WCN_rireki_all.csvに車両コード列追加作業開始"
# WCN_rireki_all.csv を処理して./WCN_rireki_all_add_syaryocode.csvを出力
awk -F, -v OFS=, 'NR==FNR {
    map[$1] = $2;
    next
}
{
    key = $7 $8 $9 $10;  # WCN_rireki_all.csv からキーを生成
    if (map[key] != "") {
        print $1, $2, $3, $4, $5, $6, map[key], $7, $8, $9, $10;
    } else {
        print $1, $2, $3, $4, $5, $6, "*", $7, $8, $9, $10;  # マッチしない場合
    }
}' ./key_syaryocode_map.txt ./WCN_rireki_all.csv > ./WCN_rireki_all_add_syaryocode.csv

# 車両コード追加ファイルを、./WCN_rireki_all.csvとしてリネーム
mv ./WCN_rireki_all_add_syaryocode.csv ./WCN_rireki_all.csv
echo "=== WCN_rireki_all.csvに車両コード列追加作業完了"


#********************************************************************************************************************
# WCN_rireki_all.csv（全アンテナ通過履歴）のナンバープレート情報を変換し、大型/小型の列を追加した提出用ファイルを作成
#********************************************************************************************************************

# output_file内のナンバープレート情報を変換し、大型/小型別ファイルとして作成、文字コードをShift-JISに変換する。
./convert_number_plate_data "${output_file}"   # output_update -> WCN_rireki_all_numberplate.csv が作成される。

# WCN_rireki_all_numberplate.csvを参照し、日毎のファイルを作成する。
# 指定された日付範囲でループして、各日付に対応する行を抽出
rm -rf ${output_day_dir}/*.csv

# 一時ファイル名を定義
temp_file="${output_update}.tmp"
#cp -rp "./WCN_rireki_all_numberplate.csv" "./WCN_rireki_all_numberplate.csv.debug"

# ヘッダーを一時ファイルに保存し、本体ファイルからヘッダーを削除
head -n 1 "$output_update" > "$temp_file"
tail -n +2 "$output_update" > "${output_update}.body"
#cp -rp "./${temp_file}" "././${temp_file}.debug" # ヘッダー行のはず
#cp -rp "./${output_update}.body" "./${output_update}.before_sort_body.debug" # ソート前のボディ

# 本体ファイルを1列目を基に数値降順でソート
sort -t, -k1,1nr "${output_update}.body" >> "${temp_file}"

# ソートされたデータを含む一時ファイルから重複データを削除し、元のファイル名にリネーム
uniq "${temp_file}" > "$output_update"

#cp -rp "./${output_update}" "./${output_update}.after_sort_body.debug" # ソート後のボディ

# 不要な中間ファイルを削除
rm "${output_update}.body"


# 日毎にファイル分割し、別ディレクトリへ保存する
split_day_WCN_rireki_csv 20231129 20231130
#split_day_WCN_rireki_csv 20231201 20231220

# WCN_rireki_all_numberplate.csvの1列目（日付時刻）を、YYYY/MM/DD, hh:mm:ss に変更する
# 列数も増える 日時 → 日付, 時刻
# YYYYMMDDhhmmssxxx → YYYY/MM/DD, hh:mm:ss

awk -F, 'BEGIN{OFS=","} NR==1 {print "日付,時刻,"substr($0, index($0,$2))} NR>1 {print substr($1,1,4)"/"substr($1,5,2)"/"substr($1,7,2)","substr($1,9,2)":"substr($1,11,2)":"substr($1,13,2),$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13}' ${output_update} > "${output_update}.work"
mv "${output_update}.work" ${output_update}
rm -rf "${output_update}.work"

# WCN_rireki_all.csvとWCN_rireki_all_numberplate.csvをoutput_day_orgにコピー
cp -rp ${output_file} ${output_day_org}/
cp -rp ${output_update} ${output_day_org}/


# 最後にファイルフォーマットをShift-JISへ変換
for file in "${output_day_dir}"/*.csv; do
    # 一時的な新しいファイル名を生成
    base_filename=$(basename "$file")
    temp_file="${output_day_dir}/${base_filename%.csv}.tmp"

    # UTF-8からShift-JISに変換し、一時ファイルに保存
    iconv -f UTF-8 -t SHIFT-JIS "$file" > "$temp_file"

    # 元のファイルを削除
    rm -rf "$file"

    # 一時ファイルを元のファイル名にリネーム
    mv "$temp_file" "$file"
done

for file in "${output_day_org}"/*.csv; do
    # 一時的な新しいファイル名を生成
    base_filename=$(basename "$file")
    temp_file="${output_day_org}/${base_filename%.csv}.tmp"

    # UTF-8からShift-JISに変換し、一時ファイルに保存
    iconv -f UTF-8 -t SHIFT-JIS "$file" > "$temp_file"

    # 元のファイルを削除
    rm -rf "$file"

    # 一時ファイルを元のファイル名にリネーム
    mv "$temp_file" "$file"
done

