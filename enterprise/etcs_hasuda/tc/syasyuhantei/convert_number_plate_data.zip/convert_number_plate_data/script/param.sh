#!/bin/bash

# 出力ファイル名の基本部分を定義(日付とくっつけてcsvファイル名にする)
output_base="WCN_rireki_all"

# 現在の日付を取得（YYYYMMDD形式）
today=$(date +%Y%m%d)

# もろもろの出力ファイル名を定義
output_file="${output_base}.csv"                   # 全アンテナの通過履歴
backup_file="${output_base}_${today}_bk.csv"       # 全アンテナ通過履歴の処理前バックアップ
output_day_org="../30_analyse/00_WCN_rireki_org"   # 日毎分割前の通過履歴配置場所
output_day_dir="../30_analyse/10_WCN_rireki_day"   # 日毎分割後の通過履歴配置場所
output_update="WCN_rireki_all_numberplate.csv"  # convert_number_plate_dataにより生の通過履歴のナンバープレート情報を変換


## 複数のWCN_rireki.csvを一本化する
cat_WCN_rireki_csv() {

    start_day=$1
    end_day=$2
    missing_count=0
    
#    for i in $(seq "${start_day}" "${end_day}"); do
    for ((i=start_day; i<=end_day; i++)); do
        dir="tc_csv_table.$i"
        file="$dir/WCN_rireki.csv"

        # ディレクトリとファイルの存在をチェック
        if [[ -d "$dir" && -f "$file" ]]; then
            # ファイルを出力ファイルに結合
            cat "$file" >> "$output_file"
        else
            echo "${file}を見つけられませんでした。"
            ((missing_count++))
        fi
    done

    # 存在しなかったファイルの数を報告
    if [[ $missing_count -gt 0 ]]; then
        echo "合計${missing_count}個のファイルが見つかりませんでした。"
    fi
}

## 一本化されたWCN_rireki_all.csvを日毎に分割する。
## あわせて、日毎の通過履歴ファイルも作成する。
split_day_WCN_rireki_csv() {

    start_day=$1
    end_day=$2
    missing_count=0
    
    for ((i=start_day; i<=end_day; i++)); do
        output_day_file="${output_day_dir}/WCN_rireki_$i.csv"
        output_antenna_day_file="${output_day_dir}/antenna_passage_count_$i.csv"

        # ナンバープレート情報変換後のファイルから、日毎別のファイルを作成する。
        # 翌日のWCN_rireki.csvに前日のデータが含まれている場合があるので、強制上書きする。
        echo "日付,時刻,アンテナ番号,WCN,ETCカード番号,ETC車種判定,ETC判定コード,ETC車種コード（自家用）,ETC車種コード（運用事業用）,支局,用途別ひらがな,種別区分,車両番号,車種" > "${output_day_file}"
        #grep -ie "^$i" "$output_update" >> "$output_day_file"
        grep -ie "^$i" "$output_update" | awk -F, '{ printf "%s/%s/%s,%s:%s:%s,%s\n", substr($1,1,4), substr($1,5,2), substr($1,7,2), substr($1,9,2), substr($1,11,2), substr($1,13,2), substr($0, length($1) + 2)}' >> "$output_day_file"
        
        # 作成した日付別ファイルから、アンテナ1号機〜3号機の通過台数と通過台数合計を算出
        # 保存ファイル名：YYYYMMDD_A?.csv → 大型車両台数、小型車両台数、通過台数合計
        A1_all=$(awk -F, '$3 == "1"' ${output_day_file} | wc -l | xargs)                       # 3列目が1の行数をカウント
        A1_other=$(awk -F, '$3 == "1" && $NF == "小型"' ${output_day_file} | wc -l | xargs)    # 3列目が1かつ末尾列が小型の行数をカウント
        A1_large=$(awk -F, '$3 == "1" && $NF == "大型"' ${output_day_file} | wc -l | xargs)    # 3列目が1かつ末尾列が大型の行数をカウント
        
        # 断面交通量ファイルに結果を出力
        echo "アンテナ,小型車,大型車,通過合計" > ${output_antenna_day_file}
        echo "A1,${A1_other},${A1_large},${A1_all}" >> ${output_antenna_day_file}
        
        A2_all=$(awk -F, '$3 == "2"' ${output_day_file} | wc -l | xargs)                       # 3列目が2の行数をカウント
        A2_other=$(awk -F, '$3 == "2" && $NF == "小型"' ${output_day_file} | wc -l | xargs)    # 3列目が2かつ末尾列が小型の行数をカウント
        A2_large=$(awk -F, '$3 == "2" && $NF == "大型"' ${output_day_file} | wc -l | xargs)    # 3列目が2かつ末尾列が大型の行数をカウント
        
        # 断面交通量ファイルに結果を追加
        echo "A2,${A2_other},${A2_large},${A2_all}" >> ${output_antenna_day_file}
        
        A3_all=$(awk -F, '$3 == "3"' ${output_day_file} | wc -l | xargs)                       # 3列目が3の行数をカウント
        A3_other=$(awk -F, '$3 == "3" && $NF == "小型"' ${output_day_file} | wc -l | xargs)    # 3列目が3かつ末尾列が小型の行数をカウント
        A3_large=$(awk -F, '$3 == "3" && $NF == "大型"' ${output_day_file} | wc -l | xargs)    # 3列目が3かつ末尾列が大型の行数をカウント
        
        # 断面交通量ファイルに結果を追加
        echo "A3,${A3_other},${A3_large},${A3_all}" >> ${output_antenna_day_file}
        
    done
}

